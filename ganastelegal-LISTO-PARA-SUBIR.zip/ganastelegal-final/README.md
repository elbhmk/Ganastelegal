# GANASTE Legal - Website

Website profesional para Ganaste Legal con integración WhatsApp.

## Setup Rápido

### 1. Clon este repositorio a tu computadora
```bash
git clone https://github.com/elbhmk/Ganastelegal.git
cd Ganastelegal
```

### 2. Instala dependencias
```bash
npm install
```

### 3. Run en desarrollo
```bash
npm run dev
```

Abre http://localhost:3000

### 4. Deploy a Vercel

Una vez en GitHub, Vercel automáticamente:
1. Detecta que es un Next.js project
2. Instala dependencias
3. Build
4. Despliega

Solo conecta tu repo a Vercel y ¡listo!

## Configuración

### WhatsApp
En `pages/index.js`, línea ~48:
```javascript
const whatsappURL = `https://wa.me/+19299244674?text=...`;
```

Cambia `+19299244674` por tu número.

### Google Sheets (Opcional)
En `pages/index.js`, línea ~52:
```javascript
const zapierWebhook = 'https://hooks.zapier.com/hooks/catch/YOUR_ZAPIER_ID/';
```

## Deploy en Vercel

1. Push code a GitHub
2. Ve a vercel.com
3. Click "Import Git Repository"
4. Selecciona tu repo
5. Click "Deploy"

¡Listo! Website estará vivo en minutos.

## Estructura
```
pages/
  index.js (Página principal)
  _app.js
styles/
  globals.css
package.json
tailwind.config.js
next.config.js
```

---

Built with Next.js + React + Tailwind CSS
