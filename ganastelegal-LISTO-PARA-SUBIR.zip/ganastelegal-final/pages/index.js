import React, { useState } from 'react';
import { Send, Phone, Mail, MapPin, CheckCircle, ArrowRight } from 'lucide-react';

export default function Home() {
  const [formData, setFormData] = useState({
    nombre: '',
    telefono: '',
    email: '',
    tipo_caso: '',
    mensaje: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const mensajeWhatsApp = `Hola, me llamo ${formData.nombre}. Mi teléfono es ${formData.telefono}. Mi caso es: ${formData.tipo_caso}. ${formData.mensaje}`;
      const whatsappURL = `https://wa.me/+19299244674?text=${encodeURIComponent(mensajeWhatsApp)}`;
      
      try {
        const zapierWebhook = 'https://hooks.zapier.com/hooks/catch/YOUR_ZAPIER_ID/';
        await fetch(zapierWebhook, {
          method: 'POST',
          body: JSON.stringify({
            nombre: formData.nombre,
            telefono: formData.telefono,
            email: formData.email,
            tipo_caso: formData.tipo_caso,
            mensaje: formData.mensaje,
            fecha: new Date().toLocaleDateString('es-ES'),
            hora: new Date().toLocaleTimeString('es-ES')
          })
        }).catch(() => {});
      } catch (e) {
        console.log('Zapier optional');
      }

      setSubmitted(true);
      
      setTimeout(() => {
        window.open(whatsappURL, '_blank');
        setFormData({ nombre: '', telefono: '', email: '', tipo_caso: '', mensaje: '' });
      }, 2000);

      setTimeout(() => {
        setSubmitted(false);
      }, 4000);

    } catch (error) {
      console.error('Error:', error);
      alert('Hubo un error. Por favor intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black text-white">
      
      {/* HEADER */}
      <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-amber-600/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-3">
              <div className="text-3xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                GANASTE
              </div>
              <div className="text-sm text-gray-400 hidden sm:block">
                <p className="font-semibold">Legal</p>
              </div>
            </div>
            <button 
              onClick={() => document.getElementById('contacto').scrollIntoView({ behavior: 'smooth' })}
              className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-black font-bold rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/50"
            >
              Consulta Gratis
            </button>
          </div>
        </div>
      </header>

      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-20 pb-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            
            {/* LEFT - TEXT */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-6xl font-black leading-tight">
                  <span className="text-white">Si te lesionaste en el trabajo,</span>
                  <br />
                  <span className="bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">tienes derechos</span>
                </h1>
                <p className="text-xl text-gray-300 leading-relaxed">
                  Conectamos trabajadores hispanos con abogados certificados. Consultorías legales en español, sin compromisos.
                </p>
              </div>

              <div className="space-y-3 pt-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-amber-500 flex-shrink-0" />
                  <span className="text-gray-300">Consulta inicial 100% GRATIS</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-amber-500 flex-shrink-0" />
                  <span className="text-gray-300">Abogados certificados conectados</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-amber-500 flex-shrink-0" />
                  <span className="text-gray-300">Atendemos en español</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-amber-500 flex-shrink-0" />
                  <span className="text-gray-300">Tus derechos están protegidos</span>
                </div>
              </div>

              <button 
                onClick={() => document.getElementById('contacto').scrollIntoView({ behavior: 'smooth' })}
                className="mt-8 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-black font-bold text-lg rounded-lg transition-all duration-300 hover:shadow-2xl hover:shadow-amber-500/50 flex items-center gap-2 w-fit"
              >
                Solicita tu Consulta Gratis
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            {/* RIGHT - IMAGE PLACEHOLDER */}
            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-amber-600/20 to-amber-900/20 rounded-2xl border-2 border-amber-600/30 flex items-center justify-center overflow-hidden">
                <div className="text-center">
                  <div className="text-6xl mb-4">⚖️</div>
                  <p className="text-amber-400 font-bold text-lg">Liliana Santander</p>
                  <p className="text-sm text-gray-400">Paralegal | Especialista en Derechos Laborales</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICIOS */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-amber-900/10 to-transparent">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Áreas de Especialidad
            </h2>
            <p className="text-xl text-gray-400">Conectamos tu caso con el abogado certificado correcto</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                titulo: "Accidentes de Trabajo",
                descripcion: "Fracuras, quemaduras, lesiones. Recibe compensación por tu lesión laboral.",
                icono: "🏗️"
              },
              {
                titulo: "Derechos Laborales",
                descripcion: "Salarios no pagados, horas extras, despido injusto. Defendemos tus derechos.",
                icono: "⚖️"
              },
              {
                titulo: "Lesiones Personales",
                descripcion: "Accidentes con auto, resbalones, negligencia. Si no fue tu culpa, hay dinero.",
                icono: "🚗"
              },
              {
                titulo: "Compensación Laboral",
                descripcion: "Navegamos trámites legales por ti. Tú recuperate, nosotros gestiona.",
                icono: "💼"
              }
            ].map((servicio, idx) => (
              <div key={idx} className="p-8 bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-amber-600/20 rounded-xl hover:border-amber-500/50 transition-all duration-300 hover:bg-gray-800/70 group">
                <div className="text-5xl mb-4">{servicio.icono}</div>
                <h3 className="text-2xl font-bold mb-3 group-hover:text-amber-400 transition-colors">{servicio.titulo}</h3>
                <p className="text-gray-400 leading-relaxed">{servicio.descripcion}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIOS */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Lo Que Dicen Nuestros Clientes
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                nombre: "Carlos M.",
                ubicacion: "Astoria, Queens",
                texto: "Tenía miedo de hablar. Liliana me explicó todo en español, sin presión. Hoy tengo dinero para mi familia."
              },
              {
                nombre: "María L.",
                ubicacion: "Washington Heights",
                texto: "No sabía que podía reclamar. Mi jefe me dijo que olvidara el accidente. Gracias a GANASTE, recibí lo que merecía."
              },
              {
                nombre: "Juan P.",
                ubicacion: "Long Island",
                texto: "Proceso rápido y claro. Me conectaron con un abogado excelente. Recomiendo a todos mis amigos."
              },
              {
                nombre: "Rosa T.",
                ubicacion: "The Bronx",
                texto: "Mejor decisión que tomé. Sin ellos, habría perdido miles de dólares."
              }
            ].map((testimonio, idx) => (
              <div key={idx} className="p-8 bg-gradient-to-br from-amber-900/20 to-gray-900/50 border border-amber-600/30 rounded-xl">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-amber-400 text-lg">★</span>
                  ))}
                </div>
                <p className="text-gray-300 mb-4 italic">"{testimonio.texto}"</p>
                <div>
                  <p className="font-bold text-white">{testimonio.nombre}</p>
                  <p className="text-sm text-gray-400">{testimonio.ubicacion}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FORMULARIO CONTACTO */}
      <section id="contacto" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-amber-900/5 to-transparent">
        <div className="max-w-2xl mx-auto">
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-amber-600/30 rounded-2xl p-8 md:p-12">
            
            <h2 className="text-4xl font-black mb-2 text-center">
              Solicita Tu Consulta Gratis
            </h2>
            <p className="text-gray-400 text-center mb-8">
              Completa el formulario y nos contactaremos en menos de 5 minutos
            </p>

            {submitted ? (
              <div className="bg-gradient-to-br from-green-900/30 to-green-800/20 border border-green-500/50 rounded-lg p-8 text-center">
                <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-green-400 mb-2">¡Gracias!</h3>
                <p className="text-gray-300">Tu consulta fue enviada exitosamente. Te contactaremos por WhatsApp en segundos.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Nombre Completo *
                  </label>
                  <input
                    type="text"
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white placeholder-gray-500 transition-all duration-300"
                    placeholder="Tu nombre"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Teléfono / WhatsApp *
                    </label>
                    <input
                      type="tel"
                      name="telefono"
                      value={formData.telefono}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white placeholder-gray-500 transition-all duration-300"
                      placeholder="+1 (XXX) XXX-XXXX"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Email (Opcional)
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white placeholder-gray-500 transition-all duration-300"
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Tipo de Caso *
                  </label>
                  <select
                    name="tipo_caso"
                    value={formData.tipo_caso}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white transition-all duration-300"
                  >
                    <option value="">Selecciona un tipo de caso</option>
                    <option value="Accidente de Trabajo">Accidente de Trabajo</option>
                    <option value="Derechos Laborales">Derechos Laborales</option>
                    <option value="Lesión Personal">Lesión Personal</option>
                    <option value="Compensación Laboral">Compensación Laboral</option>
                    <option value="Otro">Otro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Cuéntanos tu caso (breve descripción)
                  </label>
                  <textarea
                    name="mensaje"
                    value={formData.mensaje}
                    onChange={handleChange}
                    rows="4"
                    className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-white placeholder-gray-500 transition-all duration-300 resize-none"
                    placeholder="¿Qué pasó? ¿Cuándo fue? Cuéntanos..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full px-6 py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:from-gray-600 disabled:to-gray-700 text-black font-bold text-lg rounded-lg transition-all duration-300 hover:shadow-2xl hover:shadow-amber-500/50 disabled:shadow-none flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Enviar Consulta Gratis
                    </>
                  )}
                </button>

                <p className="text-xs text-gray-500 text-center">
                  Al enviar, aceptas nuestros términos. Tu información es privada y segura.
                </p>

              </form>
            )}
          </div>
        </div>
      </section>

      {/* INFO CONTACTO */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-900/50 border-t border-amber-600/20">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex gap-4">
              <Phone className="w-8 h-8 text-amber-500 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg mb-1">WhatsApp</h3>
                <p className="text-gray-400">+1 (929) 924-4674</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Mail className="w-8 h-8 text-amber-500 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg mb-1">Email</h3>
                <p className="text-gray-400">contacto@ganastelegal.com</p>
              </div>
            </div>
            <div className="flex gap-4">
              <MapPin className="w-8 h-8 text-amber-500 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg mb-1">Ubicación</h3>
                <p className="text-gray-400">NYC & Surrounding Areas</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-8 px-4 sm:px-6 lg:px-8 bg-black border-t border-amber-600/20">
        <div className="max-w-6xl mx-auto text-center text-gray-500 text-sm">
          <p>&copy; 2024 GANASTE Legal. Todos los derechos reservados.</p>
          <p className="mt-2">Servicios legales | Consultoría en español | NYC</p>
          <p className="mt-4 text-xs text-gray-600">
            Conectamos clientes con abogados certificados. Consulta inicial 100% gratis.
          </p>
        </div>
      </footer>
    </div>
  );
}
